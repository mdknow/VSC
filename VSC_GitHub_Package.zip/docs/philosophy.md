# Philosophy

Thinking is treated as an emergent property of finite systems under uncertainty.
