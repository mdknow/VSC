# Structured Incompleteness

Reality must remain larger than the model.
