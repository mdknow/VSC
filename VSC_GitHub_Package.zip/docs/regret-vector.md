# Regret Vector

R = w_m · (F_cf - F_real)
