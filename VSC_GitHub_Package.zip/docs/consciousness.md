# Consciousness Hypothesis

Consciousness may emerge from metastable self-modeling loops.
