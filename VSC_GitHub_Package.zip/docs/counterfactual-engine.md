# Counterfactual Engine

Simulates unrealized futures.
