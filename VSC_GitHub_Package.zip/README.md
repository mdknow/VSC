# VSC — Vector Survival Cosmos

## A Framework for Emergent Cognition Under Irreducible Uncertainty

VSC explores how cognition, identity, regret, curiosity, abstraction and civilization-level behaviors may emerge from finite agents operating under irreducible uncertainty.

### Core Principles
- Structured Incompleteness
- Self-Vector
- Counterfactual Engine
- Regret Vector
- Curiosity Gradient
- Memory Decay
- Conceptual Attractors
- Legacy Attractor
- Reality-Bounded Imagination

### Central Question
> What conditions force thinking to emerge?

See docs for details.
